#ifndef _TYPEDEF_
#define _TYPEDEF_

typedef unsigned char byte;
typedef __xdata byte xbyte;
typedef unsigned short word;
typedef __xdata word xword;
typedef __xdata int xint;
typedef unsigned long dword;
typedef __xdata dword xdword;
typedef __xdata long xlong;

#endif
